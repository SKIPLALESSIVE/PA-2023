<!DOCTYPE html>
<html>
<head>
    <title> Voir les réservations</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
<?php 
include "core/functions.php"; 
include "const.inc.php"; 
session_start(); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<div class="mb-5 center-text">
    <section class="page-section cta-custom">
        <div class="cta-custom cta-inner">
            <h1 class="blue site-heading-upper mb-3 change-text">Voir les réservations</h1>
            <?php
            // Vérifier si l'utilisateur est connecté
            redirectIfNotConnected();
            
            $connect = connectDB();

            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_reservation'])) {
                $reservationIdToDelete = $_POST['reservation_id'];
                // Supprimer la réservation de la base de données
                $queryPrepared = $connect->prepare("DELETE FROM " . DB_PREFIX . "reservation WHERE id = :id");
                $queryPrepared->execute(['id' => $reservationIdToDelete]);
            }

            // Récupérer toutes les réservations
            $queryPrepared = $connect->prepare("SELECT r.id, h.nom AS hotel_nom, r.date_debut, r.date_fin, r.places FROM " . DB_PREFIX . "reservation r INNER JOIN " . DB_PREFIX . "hotel h ON r.hotel_id = h.id");
            $queryPrepared->execute();
            $reservations = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);

            if (empty($reservations)) {
                echo "<p>Aucune réservation n'a été effectuée.</p>";
            } else {
                echo "<table>";
                echo "<tr><th>Hôtel</th><th>Date de Début</th><th>Date de Fin</th><th>Nombre de Places</th><th>Action</th></tr>";
                foreach ($reservations as $reservation) {
                    echo "<tr>";
                    echo "<td>" . $reservation['hotel_nom'] . "</td>";
                    echo "<td>" . $reservation['date_debut'] . "</td>";
                    echo "<td>" . $reservation['date_fin'] . "</td>";
                    echo "<td>" . $reservation['places'] . "</td>";
                    echo "<td>";
                    echo "<form method='post'>";
                    echo "<input type='hidden' name='reservation_id' value='" . $reservation['id'] . "'>";
                    echo "<button type='submit' name='delete_reservation' class='logout-button'>Supprimer</button>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            ?>
        </div>
    </section>
</div>
</body>
</html>
