<?php
include 'core/functions.php';
include "const.inc.php";



session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Liste des Hôtels</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>

<h1 class="white center-text">Liste des Hôtels</h1>

<!-- Formulaire de recherche en temps réel -->
<div class="mb-5 center-text">
  <section class="page-section cta-custom">
    <div class="cta-custom cta-inner">

<h2>Rechercher un hôtel</h2>
<input type="text" id="searchInput" placeholder="Rechercher un hôtel...">
<ul id="searchResults"></ul>

<!-- Affichage de la liste des hôtels avec effet d'accordéon -->
<button id='toggleHotels' class="btn btn-primary">Afficher/Masquer la liste des hôtels</button>
<ul id='hotelsList' style='display:none;'>
    <?php
    
    $connect = connectDB();
    $query = "SELECT id, emplacement, places, rénovation, nom, date_debut_fermeture, date_fin_fermeture FROM " . DB_PREFIX . "hotel";
    $queryPrepared = $connect->prepare($query);
    $queryPrepared->execute();
    $result = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);

    if ($result) {
        foreach ($result as $row) {
            echo "<li>";
            echo "Nom : " . $row['nom'] . "<br>";
            echo "Emplacement : " . $row['emplacement'] . "<br>";
            echo "Places : " . $row['places'] . "<br>";
            echo "Rénovation : " . $row['rénovation'] . "<br>";
            
            // Vérification de la période de fermeture
            $dateDebutFermeture = $row['date_debut_fermeture'];
            $dateFinFermeture = $row['date_fin_fermeture'];
            $currentDate = date('Y-m-d'); // Date actuelle au format YYYY-MM-DD
            if ($dateDebutFermeture <= $currentDate && $currentDate <= $dateFinFermeture) {
                echo "<strong>L'hôtel est fermé aujourd'hui.</strong><br>";
            }
            
            echo "<a href='core/edit_hotel.php?id=" . $row['id'] . "'><button class='logout-button'>Modifier</button></a>";
            echo "</li>";
        }
    } else {
        echo "Erreur lors de la récupération des données des hôtels.";
    }
    ?>
</ul>

<!-- Formulaire d'ajout d'un nouvel hôtel -->
<h2>Ajouter un nouvel hôtel</h2>
<form method="POST" action="core/insert_hotel.php">
    <label for="emplacement">Emplacement :</label>
    <select id="emplacement" name="emplacement" required>
        <option value="Orléans">Orléans</option>
        <option value="Nantes">Nantes</option>
        <option value="Blois">Blois</option>
        <option value="Saint-Florent-Le-Vieil">Saint-Florent-Le-Vieil</option>
        <option value="Thoureil">Thoureil</option>
        <option value="Cunault">Cunault</option>
        <option value="Béhuard">Béhuard</option>
        <option value="Saumur">Saumur</option>
        <option value="Tours">Tours</option>
        <option value="Ambroise">Ambroise</option>
        <option value="Montsoreau">Montsoreau</option>
        <option value="Fleury">Fleury</option>
        <option value="Sancerre">Sancerre</option>
        <option value="Apremont">Apremont</option>

    </select><br>
    <label for="places">Places :</label>
    <input type="number" name="places" required><br>
    <label for="name">Nom :</label>
    <input type="text" name="name" required><br>
    <label for="prix">Prix :</label>
    <input type="number" name="prix" required><br>
    <label for="renovation">Rénovation :</label>
    <input type="radio" name="renovation" value="1" required> Oui
    <input type="radio" name="renovation" value="0"> Non<br>
    <input type="submit" class="btn btn-primary" value="Ajouter un hôtel">
</form>


<!-- Script JavaScript pour la recherche en temps réel -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    const hotelsList = document.getElementById('hotelsList');
    
    searchInput.addEventListener('input', function() {
        const searchValue = searchInput.value.trim().toLowerCase();
        searchResults.innerHTML = '';

        if (searchValue === '') {
            hotelsList.style.display = 'block';
            return;
        }

        hotelsList.style.display = 'none';
        
        <?php
        foreach ($result as $row) {
            echo "if (";
            echo "'{$row['nom']}'";
            echo ".toLowerCase().includes(searchValue) || ";
            echo "'{$row['emplacement']}'";
            echo ".toLowerCase().includes(searchValue)) {";
            echo "const li = document.createElement('li');";
            echo "li.innerHTML = 'Nom : " . $row['nom'] . "<br>" .
                "Emplacement : " . $row['emplacement'] . "<br>" .
                "Places : " . $row['places'] . "<br>" .
                "Rénovation : " . $row['rénovation'] . "<br>';";
            echo "searchResults.appendChild(li);";
            echo "}";
        }
        ?>
    });
});
</script>

<!-- Script JavaScript pour l'effet d'accordéon -->
<script>
document.getElementById('toggleHotels').addEventListener('click', function() {
    var hotelsList = document.getElementById('hotelsList');
    if (hotelsList.style.display === 'none') {
        hotelsList.style.display = 'block';
    } else {
        hotelsList.style.display = 'none';
    }
});
</script>
</div>
</section>
</div> 

</body>
</html>