<?php 
    include "core/functions.php"; 
    include "const.inc.php"; 
    session_start(); 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    $connect = connectDB(); 

    // Suppression d'un pack
    if (isset($_POST['deletePack'])) {
        $packId = $_POST['deletePack'];
        $queryDelete = $connect->prepare("DELETE FROM " . DB_PREFIX . "pack WHERE id = :packId");
        $queryDelete->bindParam(":packId", $packId, PDO::PARAM_INT);
        $queryDelete->execute();
    }

    // Récupération de la liste des packs
    $queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "pack"); 
    $queryPrepared->execute();
    $results = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Liste des packs</title>
    <link href="css/styles.css" rel="stylesheet"/>
          <link href="css/perso.css" rel="stylesheet" />
</head>
<body>>
    <h2 class="center-text margin-top changePai" >Liste des packs :</h2>
    <div class="row-ua">
  <section class="page-section cta-A bg-faded">
    <div class="cta-A cta-inner">
    <ul>
        <?php foreach ($results as $pack) { ?>
            <li>

             <span class="center-text pack"> Pack ID: <?php echo $pack['id']; ?> </span> <br>- <span class=" mb-3 white">Description: <?php echo $pack['description']; ?> </span> 
                <form method="post" action="">
                    <input type="hidden" name="deletePack" value="<?php echo $pack['id']; ?>">
                    <br>
                    <button type="submit" class="btn btn-primary-A">Supprimer</button>
                </form>
            </li>
        <?php } ?>
    </ul>
    <br> 
    <a href="Aresahotels.php" class="btn btn-primary-A">Lien vers la page de création de pack</a>
        </div>
        </section> 
        </div> 
</body>
</html>
