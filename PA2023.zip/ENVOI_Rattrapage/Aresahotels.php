<!DOCTYPE html>
<html>
<head>
    <title>Ajouter des étapes</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
    <?php 
    include "core/functions.php"; 
    include "const.inc.php"; 
    session_start(); 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    ?>

    <?php  if (isset($_SESSION['ListOfErrors']) && count($_SESSION['ListOfErrors']) > 0){ ?>
        <div class="error-container">
            <h3>Erreurs:</h3>
            <ul>
                <?php foreach ($_SESSION['ListOfErrors'] as $error){ ?>
                    <li><?php echo $error; ?></li>
                <?php } ?>
            </ul>
        </div>
    <?php 
    unset($_SESSION['ListOfErrors']); 
    };
    ?>
    <h2 class="text-center white "> Formulaire de création de pack :  </h2>

    <div class="bg faded text-center page section cta-A mt-4 center-text"> 
        <div id="etapes-container">
            <!-- Conteneur pour les formulaires d'étapes -->
        </div>
        <div class="mt-4"> 
            <div class="mt-4"> 
                <button type="button" id="add-etapes-button" class="btn btn-primary-A">Ajouter une étape</button>
                <button type="button" id="creer-pack-button" class="btn btn-primary-A">Créer un pack</button>
            </div>
        </div>
    </div> 

    <script>
        const targetDir = "../assets/img/hotel/";
        const etapeForms = [];

        document.addEventListener("DOMContentLoaded", function() {
            const addEtapesButton = document.getElementById('add-etapes-button');
            const etapesContainer = document.getElementById('etapes-container');
            const creerPackButton = document.getElementById('creer-pack-button');

            function addEtapeForm() {
                const etapeForm = document.createElement('form');
                etapeForm.className = 'etape-form';
                etapeForm.method = 'POST';

                const dateStartInput = document.createElement('input');
                dateStartInput.type = 'date';
                dateStartInput.name = 'date-start';
                dateStartInput.placeholder = 'Date de début';
                dateStartInput.required = true;

                const dateEndInput = document.createElement('input');
                dateEndInput.type = 'date';
                dateEndInput.name = 'date-end';
                dateEndInput.placeholder = 'Date de fin';
                dateEndInput.required = true;

                const emplacementSelect = document.createElement('select');
                emplacementSelect.name = 'ville';
                emplacementSelect.required = true;
                const cities = ['Orléans', 'Blois', 'Nantes', 'Saint-Florent-Le-Vieil', 'Le Thoureil', 'Cunault', 'Béhuard', 'Saumur', 'Tours', 'Ambroise', 'Montsoreau', 'Fleury', 'Sancerre', 'Apremont'];

                cities.forEach(city => {
                    const option = document.createElement('option');
                    option.value = city;
                    option.textContent = city;
                    emplacementSelect.appendChild(option);
                });

                const submitButton = document.createElement('button');
                submitButton.type = 'button';
                submitButton.textContent = 'Rechercher';
                submitButton.className = 'logout-button';
                submitButton.addEventListener('click', function() {
                    const formData = new FormData(etapeForm);

                    fetch('core/ByaskEnginer.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        const etapeResults = etapeForm.querySelector('.etape-results');
                        if (etapeResults) {
                            etapeResults.remove();
                        }

                        const newEtapeResults = document.createElement('div');
                        newEtapeResults.className = 'etape-results';

                        data.forEach(hotel => {
                            const hotelDiv = document.createElement('div');
                            for (const key in hotel) {
                                if (hotel[key] !== null && key !== 'renovation' && key !== 'date_debut' && (key !== 'date_fin' || hotel[key] !== null)) {
                                    hotelDiv.textContent += key + ': ' + hotel[key] + ', ';
                                }
                            }

                            const hotelImage = document.createElement('img');
                            hotelImage.src = targetDir + hotel.id + '.png';
                            hotelImage.className = 'resized-image';
                            hotelDiv.appendChild(hotelImage);

                            const hotelIdLabel = document.createElement('label');
                            hotelIdLabel.textContent = 'ID: ' + hotel.id;
                            hotelIdLabel.htmlFor = 'hotel-checkbox-' + hotel.id;

                            const hotelIdInput = document.createElement('input');
                            hotelIdInput.type = 'checkbox';
                            hotelIdInput.name = 'hotel-id';
                            hotelIdInput.value = hotel.id;
                            hotelIdInput.className = 'hotel-checkbox';
                            hotelIdInput.id = 'hotel-checkbox-' + hotel.id;

                            const addButton = document.createElement('button');
                            addButton.type = 'button';
                            addButton.textContent = 'Ajouter au pack';
                            addButton.className = 'logout-button'; 
                            addButton.disabled = true;

                            addButton.addEventListener('click', function() {
                                if (hotelIdInput.checked) {
                                    hotelIdInput.checked = false;
                                } else {
                                    hotelIdInput.checked = true;
                                }
                            });

                            const hotelActionContainer = document.createElement('div');
                            hotelActionContainer.appendChild(hotelIdLabel);
                            hotelActionContainer.appendChild(hotelIdInput);
                            hotelActionContainer.appendChild(addButton);

                            hotelDiv.appendChild(hotelActionContainer);

                            newEtapeResults.appendChild(hotelDiv);
                        });

                        etapeForm.insertBefore(newEtapeResults, submitButton);
                    })
                    .catch(error => {
                        console.error('Une erreur s\'est produite lors de la récupération des données:', error);
                    });
                });

                etapeForm.appendChild(dateStartInput);
                etapeForm.appendChild(dateEndInput);
                etapeForm.appendChild(emplacementSelect);
                etapeForm.appendChild(submitButton);

                etapeForms.push(etapeForm);
                etapesContainer.appendChild(etapeForm);
            }

            addEtapesButton.addEventListener('click', addEtapeForm);

            creerPackButton.addEventListener('click', function() {
                const selectedHotelIds = [];

                etapeForms.forEach(etapeForm => {
                    const hotelIdInput = etapeForm.querySelector('.hotel-checkbox:checked');
                    if (hotelIdInput) {
                        selectedHotelIds.push(hotelIdInput.value);
                    }
                });

                if (selectedHotelIds.length > 0) {
                    const packName = prompt("Entrez le nom du pack :");
                    const packDescription = prompt("Entrez la description du pack :");

                    if (packName !== null && packDescription !== null) {
                        const formData = new FormData();
                        formData.append('createPack', true);
                        formData.append('hotelIds', selectedHotelIds.join('e'));
                        formData.append('packName', packName); // Ajout de l'attribut packName
                        formData.append('packDescription', packDescription);

                        fetch('core/create_pack.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text())
                        .then(message => {
                            alert(message);
                        })
                        .catch(error => {
                            console.error('Une erreur s\'est produite lors de la création du pack:', error);
                        });
                    }
                } else {
                    alert('Veuillez sélectionner au moins un hôtel pour créer un pack.');
                }
            });
        });
    </script>
</body>
</html>
