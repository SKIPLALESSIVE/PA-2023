<!DOCTYPE html>
<html>
<head>
    <title>Ajouter des étapes</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
    <h1 class="site-heading text-center text-faded d-none d-lg-block">
        <span class="blue site-heading-upper mb-3"> Réservez votre tajet à la demande ! </span>
        <span class="site-heading-lower">Laissez vous guider par le formulaire </span>
    </h1>

    <?php
    include "core/functions.php";
    include "const.inc.php";

    session_start();
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    ?>

    <?php if (isset($_SESSION['ListOfErrors']) && count($_SESSION['ListOfErrors']) > 0){ ?>
        <div class="error-container">
            <h3>Erreurs:</h3>
            <ul>
                <?php foreach ($_SESSION['ListOfErrors'] as $error){ ?>
                    <li><?php echo $error; ?></li>
                <?php } ?>
            </ul>
        </div>
    <?php
    unset($_SESSION['ListOfErrors']);
    };
    ?>

    <  <section class="page-section cta">
        <div class="container row">
            <div id="etapes-container"class="col-xl-9 mx-auto">
                <!-- Conteneur pour les formulaires d'étapes -->
            </div>
        </div>
    </section>

    <button type="button" id="add-etapes-button" class="btn btn-primary">Ajouter une étape</button>
    <button type="button" id="reserver-button" class="btn btn-primary">Réserver</button>

    <script>
        const targetDir = "../assets/img/hotel/";
        const etapeForms = [];

        document.addEventListener("DOMContentLoaded", function() {
            const addEtapesButton = document.getElementById('add-etapes-button');
            const etapesContainer = document.getElementById('etapes-container');
            const reserverButton = document.getElementById('reserver-button');

            function addEtapeForm() {
                const etapeForm = document.createElement('form');
                etapeForm.className = 'etape-form';
                etapeForm.method = 'POST';

                const dateStartInput = document.createElement('input');
                dateStartInput.type = 'date';
                dateStartInput.name = 'date-start';
                dateStartInput.placeholder = 'Date de début';
                dateStartInput.required = true;

                const dateEndInput = document.createElement('input');
                dateEndInput.type = 'date';
                dateEndInput.name = 'date-end';
                dateEndInput.placeholder = 'Date de fin';
                dateEndInput.required = true;

                const emplacementSelect = document.createElement('select');
                emplacementSelect.name = 'ville';
                emplacementSelect.required = true;
                const optionOrleans = document.createElement('option');
                optionOrleans.value = 'Orléans';
                optionOrleans.textContent = 'Orléans';


                const optionBlois = document.createElement('option');
                optionBlois.value = 'Blois';
                optionBlois.textContent = 'Blois';

                const optionNantes = document.createElement('option');
                optionNantes.value = 'Nantes';
                optionNantes.textContent = 'Nantes';

                const optionSaintFlorentLeVieil = document.createElement('option');
                optionSaintFlorentLeVieil.value = 'Saint-Florent-Le-Vieil';
                optionSaintFlorentLeVieil.textContent = 'Saint-Florent-Le-Vieil';

                const optionThoureil = document.createElement('option');
                optionThoureil.value = 'Le Thoureil';
                optionThoureil.textContent = 'Le Thoureil';

                
                const optionCunault = document.createElement('option');
                optionCunault.value = 'Cunault';
                optionCunault.textContent = 'Cunault';

                const optionBéhuard = document.createElement('option');
                optionBéhuard.value = 'Béhuard';
                optionBéhuard.textContent = 'Béhuard';

                
                const optionSaumur = document.createElement('option');
                optionSaumur.value = 'Saumur';
                optionSaumur.textContent = 'Saumur';

                
                const optionTours = document.createElement('option');
                optionTours.value = 'Tours';
                optionTours.textContent = 'Tours';

                const optionAmbroise = document.createElement('option');
                optionAmbroise.value = 'Ambroise';
                optionAmbroise.textContent = 'Ambroise';
                

                const optionMontsoreau = document.createElement('option');
                optionMontsoreau.value = 'Montsoreau';
                optionMontsoreau.textContent = 'Montsoreau';
                
                const optionFleury = document.createElement('option');
                optionFleury.value = 'Fleury';
                optionFleury.textContent = 'Fleury';

                      
                const optionSancerre = document.createElement('option');
                optionSancerre.value = 'Sancerre';
                optionSancerre.textContent = 'Sancerre';


                const optionApremont = document.createElement('option');
                optionApremont.value = 'Apremont';
                optionApremont.textContent = 'Apremont';

                emplacementSelect.appendChild(optionOrleans);
                emplacementSelect.appendChild(optionBlois);
                emplacementSelect.appendChild(optionNantes);
                emplacementSelect.appendChild(optionSaintFlorentLeVieil);
                emplacementSelect.appendChild(optionThoureil);
                emplacementSelect.appendChild(optionCunault);
                emplacementSelect.appendChild(optionBéhuard);
                emplacementSelect.appendChild(optionSaumur);
                emplacementSelect.appendChild(optionTours);
                emplacementSelect.appendChild(optionAmbroise);
                emplacementSelect.appendChild(optionMontsoreau);
                emplacementSelect.appendChild(optionFleury);
                emplacementSelect.appendChild(optionSancerre);
                emplacementSelect.appendChild(optionApremont);


                const hotelCheckbox = document.createElement('input');
                hotelCheckbox.type = 'checkbox';
                hotelCheckbox.name = 'selected-hotels[]'; // Name pour obtenir les hôtels sélectionnés
                hotelCheckbox.value = ''; // L'ID de l'hôtel pourrait être la valeur ici

                const submitButton = document.createElement('button');
                submitButton.type = 'button';
                submitButton.textContent = 'Rechercher';
                submitButton.addEventListener('click', function() {
                    const formData = new FormData(etapeForm);

                    fetch('core/ByaskEnginer.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        const etapeResults = etapeForm.querySelector('.etape-results');
                        if (etapeResults) {
                            etapeResults.remove(); // Supprimer les résultats précédents
                        }

                        const newEtapeResults = document.createElement('div');
                        newEtapeResults.className = 'etape-results';

                        data.forEach(hotel => {
                            const hotelDiv = document.createElement('div');
                            hotelDiv.className = 'hotel-entry';

                            const hotelCheckbox = document.createElement('input');
                            hotelCheckbox.type = 'checkbox';
                            hotelCheckbox.name = 'selected-hotels[]';
                            hotelCheckbox.value = hotel.id;

                            hotelDiv.appendChild(hotelCheckbox);

                            for (const key in hotel) {
                                if (hotel[key] !== null && key !== 'renovation' && key !== 'date_debut' && (key !== 'date_fin' || hotel[key] !== null)) {
                                    const hotelDetail = document.createElement('p');
                                    hotelDetail.textContent = key + ': ' + hotel[key];
                                    hotelDiv.appendChild(hotelDetail);
                                }
                            }

                            const hotelImage = document.createElement('img');
                            hotelImage.src = targetDir + hotel.id + '.png';
                            hotelDiv.appendChild(hotelImage);

                            newEtapeResults.appendChild(hotelDiv);
                        });

                        // Insérer les nouveaux résultats à la place de l'ancien conteneur
                        etapeForm.insertBefore(newEtapeResults, submitButton);
                    })
                    .catch(error => {
                        console.error('Une erreur s\'est produite lors de la récupération des données:', error);
                    });
                });

                etapeForm.appendChild(dateStartInput);
                etapeForm.appendChild(dateEndInput);
                etapeForm.appendChild(emplacementSelect);
                etapeForm.appendChild(hotelCheckbox); // Ajouter la case à cocher
                etapeForm.appendChild(submitButton);

                etapeForms.push(etapeForm);
                etapesContainer.appendChild(etapeForm);
            }

            addEtapesButton.addEventListener('click', addEtapeForm);

            reserverButton.addEventListener('click', function() {
                const selectedHotels = [];

                etapeForms.forEach(etapeForm => {
                    const hotelCheckbox = etapeForm.querySelector('input[type="checkbox"]');
                    if (hotelCheckbox.checked) {
                        const formData = new FormData(etapeForm);
                        selectedHotels.push(Object.fromEntries(formData.entries()));
                    }
                });

                // Créer la requête GET avec les hôtels sélectionnés
                const params = new URLSearchParams();
                params.append('selectedHotels', JSON.stringify(selectedHotels));

                // Rediriger vers la page de réservation avec les données GET
                window.location.href = 'ResaFinal.php?' + params.toString();
            });
        });
    </script>
</body>
</html>
