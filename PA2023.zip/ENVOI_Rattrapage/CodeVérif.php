<?php include "core/functions.php"; 
include "const.inc.php"; 
require 'vendor/autoload.php';

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$code = generateRandomCode(); 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    // Paramètres SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.mail.yahoo.com'; // Changez cela avec les détails de votre serveur SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'julienmans@yahoo.fr'; // Changez cela avec votre adresse e-mail
    $mail->Password = 'rtujpdytikaqlzvv'; // Changez cela avec votre mot de passe
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    // Destinataire
    $mail->setFrom('julienmans@yahoo.fr', 'Your Name');
    $mail->addAddress('', 'Recipient Name');

    // Contenu de l'e-mail
    $mail->Subject = $code;
    $mail->Body = 'Ceci est votre code de vérification. Vous bénéficiez de 20% de réduction à votre première commande avec le code FIRSTCOMMAND';

    // Envoyer l'e-mail
  

    $mail->send();
    echo 'L\'e-mail a été envoyé avec succès.';
} catch (Exception $e) {
    echo "Une erreur est survenue : {$mail->ErrorInfo}";
}
?>




