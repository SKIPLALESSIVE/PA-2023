-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : sam. 26 août 2023 à 13:43
-- Version du serveur : 10.5.19-MariaDB-0+deb11u2
-- Version de PHP : 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `Loire`
--

-- --------------------------------------------------------

--
-- Structure de la table `ju_hotel`
--

CREATE TABLE `ju_hotel` (
  `id` int(11) NOT NULL,
  `nom` varchar(320) NOT NULL,
  `emplacement` varchar(320) NOT NULL,
  `places` int(11) NOT NULL,
  `rénovation` int(11) NOT NULL DEFAULT 0,
  `date_debut_fermeture` date DEFAULT NULL,
  `date_fin_fermeture` date DEFAULT NULL,
  `prix` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ju_hotel`
--

INSERT INTO `ju_hotel` (`id`, `nom`, `emplacement`, `places`, `rénovation`, `date_debut_fermeture`, `date_fin_fermeture`, `prix`) VALUES
(1, 'Bella', 'Orléans', 11, 0, NULL, NULL, 100),
(2, 'Straciatella', 'Tours', 15, 0, NULL, NULL, 70),
(3, 'Ciao', 'Orléans', 23, 1, NULL, NULL, 120),
(4, 'Nanteo', 'Nantes', 12, 0, NULL, NULL, 70),
(5, 'Keepit', 'Nantes', 10, 0, NULL, NULL, 80),
(6, 'Basicos', 'Blois', 13, 0, NULL, NULL, 45),
(7, 'Sananas', 'Blois', 34, 0, NULL, NULL, 254),
(8, 'Deas', 'Saint-Florent-Le-Vieil', 8, 0, NULL, NULL, 90),
(9, 'Geraldo', 'Saint-Florent-Le-Vieil', 9, 0, NULL, NULL, 55),
(10, 'Aqso', 'Thoureil', 12, 0, NULL, NULL, 56),
(11, 'Poiuyt', 'Thoureil', 8, 1, '2023-08-27', '2023-08-31', 70),
(12, 'Serhj', 'Cunault', 4, 0, NULL, NULL, 45),
(13, 'PouRTO', 'Cunault', 8, 0, NULL, NULL, 56),
(14, 'ocsbdd', 'Béhuard', 6, 0, NULL, NULL, 67),
(15, 'ASUS', 'Béhuard', 45, 0, NULL, NULL, 78),
(16, 'hvdlflh', 'Saumur', 34, 0, NULL, NULL, 156),
(17, 'LoirerAsfgh', 'Saumur', 54, 0, NULL, NULL, 65),
(18, 'Lired', 'Tours', 123, 0, NULL, NULL, 78),
(19, 'Asdfgfh', 'Ambroise', 32, 0, NULL, NULL, 87),
(20, 'Ibis Budget', 'Montsoreau', 345, 0, NULL, NULL, 98),
(21, 'LOPIII', 'Montsoreau', 234, 0, NULL, NULL, 56),
(22, 'Merogis', 'Fleury', 54, 0, NULL, NULL, 34),
(23, 'Bellair', 'Fleury', 128, 0, NULL, NULL, 43),
(24, 'brgnhnltr', 'Sancerre', 34, 0, NULL, NULL, 78),
(25, 'Resjdsj', 'Sancerre', 2, 0, NULL, NULL, 123),
(26, 'efgegkjfhjk', 'Apremont', 345, 0, NULL, NULL, 356),
(27, 'flgsr', 'Apremont', 89, 0, NULL, NULL, 67);

-- --------------------------------------------------------

--
-- Structure de la table `ju_pack`
--

CREATE TABLE `ju_pack` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `hotel_all` varchar(320) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ju_pack`
--

INSERT INTO `ju_pack` (`id`, `nom`, `hotel_all`, `description`) VALUES
(5, 'pack début-fin', '1e27', 'un sprint ! ');

-- --------------------------------------------------------

--
-- Structure de la table `ju_reservation`
--

CREATE TABLE `ju_reservation` (
  `id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `places` int(11) NOT NULL,
  `is_payed` int(11) NOT NULL DEFAULT 0,
  `baggage_transport` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ju_reservation`
--

INSERT INTO `ju_reservation` (`id`, `hotel_id`, `user_id`, `date_debut`, `date_fin`, `places`, `is_payed`, `baggage_transport`) VALUES
(8, 1, 2, '2023-08-24', '2023-08-25', 3, 1, 0),
(9, 1, 2, '2023-08-31', '2023-09-01', 4, 0, 0),
(10, 27, 2, '2023-09-01', '2023-09-02', 4, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ju_user`
--

CREATE TABLE `ju_user` (
  `id` int(11) NOT NULL,
  `gender` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(320) NOT NULL,
  `birthday` date NOT NULL,
  `isBanned` int(11) NOT NULL DEFAULT 0,
  `date_creation` date NOT NULL DEFAULT current_timestamp(),
  `isDeleted` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL,
  `pwd` varchar(320) NOT NULL,
  `first_code` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ju_user`
--

INSERT INTO `ju_user` (`id`, `gender`, `firstname`, `lastname`, `email`, `birthday`, `isBanned`, `date_creation`, `isDeleted`, `status`, `username`, `pwd`, `first_code`) VALUES
(1, 0, 'Julien', 'MANSIAT', 'julienmans@yahoo.fr', '2004-07-31', 0, '2023-08-02', 0, 1, 'skip', '$2y$10$gCYBu3QKQn0ZreMa/Yyl7ujopHatXwiQUvR7uIJRKqMACWhbp7B1e', 0),
(2, 0, 'Julien', 'MANSIAT', 'julienlycee60@gmail.com', '2004-07-31', 0, '2023-08-07', 0, 0, 'skipu', '$2y$10$cSsEHe/EeDWRAx1Pq2mVyOl/lrZmqIZueY/uw3fgWIFDYK5AxBV3m', 0),
(4, 0, 'Julien', 'MANSIAT', 'julienmansiat@gmail.com', '2004-07-31', 0, '2023-08-14', 0, 0, 'skiphehe', '$2y$10$n2ASXxTZOjy3Z8aU8wh7tOu2GdQ2WSDkREIP3Mm7HvX2hurD3rOV.', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `ju_hotel`
--
ALTER TABLE `ju_hotel`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ju_pack`
--
ALTER TABLE `ju_pack`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ju_reservation`
--
ALTER TABLE `ju_reservation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hotel_id` (`hotel_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `ju_user`
--
ALTER TABLE `ju_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `ju_hotel`
--
ALTER TABLE `ju_hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `ju_pack`
--
ALTER TABLE `ju_pack`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `ju_reservation`
--
ALTER TABLE `ju_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `ju_user`
--
ALTER TABLE `ju_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `ju_reservation`
--
ALTER TABLE `ju_reservation`
  ADD CONSTRAINT `ju_reservation_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `ju_hotel` (`id`),
  ADD CONSTRAINT `ju_reservation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `ju_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
