<!DOCTYPE html>
<html>
<head>
    <title>Résultats de la Réservation</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
    <script>
        function showErrorMessage(message) {
            alert(message);
        }
    </script>
</head>
<body>
<h1 class="site-heading text-center text-faded d-none d-lg-block">
<span class="blue site-heading-upper mb-3 change-text">Résultats de la Réservation</span>
<span class="site-heading-lower change-text">Voici les détails de votre réservation :</span>
</h1>
<button onclick="window.location.href = 'index.php';" class="btn btn-primary">Retourner à l'accueil</button>
<section class="page-section cta"> 
<?php
include "core/functions.php";
include "const.inc.php";
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected();

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['selectedHotels'])) {
    $reservationData = $_GET['selectedHotels'];
    $PreservationData = json_decode($reservationData, true);
    $_SESSION['PreservationData'] = $PreservationData;

    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "Erreur de décodage JSON : " . json_last_error_msg();
    } else {
        $connect = connectDB();
        $userid = $_SESSION['id'];

        foreach ($PreservationData as $reservation) {
            $hotelid = $reservation['selected-hotels[]'];
            $queryPrepared = $connect->prepare("SELECT nom, places, prix FROM ".DB_PREFIX."hotel WHERE id=:id");
            $queryPrepared->execute(['id' => $hotelid]);
            $hotelDetails = $queryPrepared->fetch(PDO::FETCH_ASSOC);
            $queryReservation = "SELECT SUM(places) AS total_places FROM " . DB_PREFIX . "reservation WHERE hotel_id = :hotel_id AND date_debut <= :date_fin AND date_fin >= :date_debut";
            $queryReservationPrepared = $connect->prepare($queryReservation);
            $queryReservationPrepared->execute(['hotel_id' => $hotelid, 'date_debut' => $reservation['date-start'], 'date_fin' => $reservation['date-end']]);
            $reservationInfo = $queryReservationPrepared->fetch(PDO::FETCH_ASSOC);
            $reservedPlaces = $reservationInfo['total_places'];
            $availablePlaces = $hotelDetails['places'] - $reservedPlaces;
            echo "<div class= 'container row'>"; 
            echo "<form method='post' action=''>";
            echo "<input type='hidden' name='reservationData' value='$reservationData'>";
            echo "<input type='hidden' name='hotelid' value='$hotelid'>";
            echo "<input type='hidden' name='userid' value='$userid'>";
            echo "<p>Hôtel : " . $hotelDetails['nom'] . "</p>";
            echo "<p>Emplacement : " . $reservation['ville'] . "</p>";
            echo "<label for='new-date-start'>Date de Début de séjour:</label>";
            echo "<input type='date' id='new-date-start' name='new-date-start_$hotelid' required>";
            echo "<label for='new-date-end'>Date de Fin de séjour :</label>";
            echo "<input type='date' id='new-date-end' name='new-date-end_$hotelid' required>";
            echo "<label for='places'>Nombre de places :</label>";
            echo "<input type='number' id='places' name='places_$hotelid' min='1' max='$availablePlaces' required value='0'>";
            echo "<button type='submit' name='reserver_hotel_$hotelid' class='btn btn-primary'>Réserver</button>";
            echo "</form>";
            echo "</div>"; 
        }
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $PreservationData = $_SESSION['PreservationData'];
    $connect = connectDB();
    $userid = $_SESSION['id'];
    $hasErrors = false;

    foreach ($PreservationData as $reservation) {
        $hotelid = $reservation['selected-hotels[]'];
        if (isset($_POST['reserver_hotel_' . $hotelid])) {
            $newDateStart = $_POST['new-date-start_' . $hotelid];
            $newDateEnd = $_POST['new-date-end_' . $hotelid];
            $nombreDePlaces = $_POST['places_' . $hotelid];

            $queryPrepared = $connect->prepare("SELECT nom, places, prix, rénovation, date_debut_fermeture, date_fin_fermeture FROM ".DB_PREFIX."hotel WHERE id=:id");
            $queryPrepared->execute(['id' => $hotelid]);
            $hotelDetails = $queryPrepared->fetch(PDO::FETCH_ASSOC);

            if (isset($hotelDetails['rénovation']) && $hotelDetails['rénovation'] == 1) {
                $hasErrors = true;
                echo "<script>showErrorMessage('L\'hôtel est en travaux pour le moment');</script>";
            } else if (isset($newDateEnd, $newDateStart, $hotelDetails['date_debut_fermeture'], $hotelDetails['date_fin_fermeture']) &&
                       (($newDateEnd >= $hotelDetails['date_debut_fermeture'] && $newDateEnd <= $hotelDetails['date_fin_fermeture']) ||
                       ($newDateStart >= $hotelDetails['date_debut_fermeture'] && $newDateStart <= $hotelDetails['date_fin_fermeture']) ||
                       ($newDateStart <= $hotelDetails['date_debut_fermeture'] && $newDateEnd >= $hotelDetails['date_fin_fermeture']))) {
               $hasErrors = true;
               echo "<script>showErrorMessage('L\'hôtel est fermé à ces dates' Retournez sur la page de sélection des étapes);</script>";
            } else {
                $queryReservation = "SELECT SUM(places) AS total_places FROM " . DB_PREFIX . "reservation WHERE hotel_id = :hotel_id AND date_debut <= :date_fin AND date_fin >= :date_debut";
                $queryReservationPrepared = $connect->prepare($queryReservation);
                $queryReservationPrepared->execute(['hotel_id' => $hotelid, 'date_debut' => $newDateStart, 'date_fin' => $newDateEnd]);
                $reservationInfo = $queryReservationPrepared->fetch(PDO::FETCH_ASSOC);
                $reservedPlaces = $reservationInfo['total_places'];
                $availablePlaces = $hotelDetails['places'] - $reservedPlaces;

                if ($nombreDePlaces <= 0 || $nombreDePlaces > $availablePlaces) {
                    $hasErrors = true;
                    echo "<p>Erreurs :</p>";
                    if ($nombreDePlaces <= 0) {
                        echo "<p>Nombre de places invalide.</p>";
                    } else {
                        echo "<p>Plus assez de places disponibles pour l'hôtel : " . $hotelDetails['nom'] . "</p>";
                    }
                    continue;
                }
                $queryPrepared = $connect->prepare("INSERT INTO ".DB_PREFIX."reservation (hotel_id, user_id, date_debut, date_fin, places) VALUES (:hotel_id, :user_id, :date_debut, :date_fin, :places)");
                $queryPrepared->execute([
                    'hotel_id' => $hotelid,
                    'user_id' => $userid,
                    'date_debut' => $newDateStart,
                    'date_fin' => $newDateEnd,
                    'places' => $nombreDePlaces
                ]);
            }
        }
    }
    if (!$hasErrors) {
        echo "<h2>Données de réservation envoyées :</h2>";
        echo "<pre>";
        echo "Il vous suffit de faire un retour en arrière pour continuer vos réservations ! Vous avez 3 jours pour payer ces réservations sur votre espace client"; 
        echo "</pre>";
    }
} else {
    echo "<h2>Données non envoyées pour la réservation.</h2>";
}
?>
</section>
</body>
</html>
