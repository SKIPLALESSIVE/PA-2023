<?php 
include "template/header.php"; 
include "core/functions.php"; 
include "const.inc.php"; 
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
RedirectIfNotConnected(); 

$connect = connectDB(); 

// Suppression d'une réservation si le formulaire est soumis
if (isset($_POST['delete_reservation'])) {
    $reservationId = $_POST['reservation_id'];
    $queryPrepared = $connect->prepare("DELETE FROM " . DB_PREFIX . "reservation WHERE id = :reservation_id"); 
    $queryPrepared->bindValue(':reservation_id', $reservationId, PDO::PARAM_INT);
    $queryPrepared->execute();
}

$queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "reservation WHERE user_id = :user_id"); 
$queryPrepared->bindValue(':user_id', $_SESSION['id'], PDO::PARAM_INT);
$queryPrepared->execute(); 
$reservations = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tableau de bord</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
<h1 class="site-heading-upper mb-3 changeuA center-text">Tableau de bord</h1>
<div class="row-ua center-text">
    <section class="page-section cta-custom">
        <div class="cta-custom cta-inner">

        <?php if (count($reservations) > 0) : ?>
            <h2>Mes réservations</h2>
            <table>
                <tr>
                    <th>ID Réservation</th>
                    <th>ID Hôtel</th>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Places réservées</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($reservations as $reservation) : ?>
                    <tr>
                        <td><?php echo $reservation['id']; ?></td>
                        <td><?php echo $reservation['hotel_id']; ?></td>
                        <td><?php echo $reservation['date_debut']; ?></td>
                        <td><?php echo $reservation['date_fin']; ?></td>
                        <td><?php echo $reservation['places']; ?></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="reservation_id" value="<?php echo $reservation['id']; ?>">
                                <button type="submit" name="delete_reservation" class="logout-button">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>Aucune réservation n'a été effectuée.</p>
        <?php endif; ?>

        </div>
    </section>
    <a href="core/UserLogout.php" class="logout-button">Se déconnecter</a>
    <a href="core/paiement.php" class="logout-button">Payer mes réservations</a>
    <a href="index.php" class="logout-button">Revenir à l'accueil</a>
</div>
</body>
</html>
