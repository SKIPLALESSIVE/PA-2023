<?php
require 'vendor/autoload.php';
include "core/functions.php";
include "const.inc.php";
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION['data'])) {
    $data = $_SESSION['data'];

    // Génération et envoi du code de vérification
    $code = '';
    for ($i = 0; $i < 6; $i++) {
        $code .= mt_rand(0, 9);
    }

    // Assurez-vous que vous avez l'adresse e-mail à laquelle envoyer le code
    $email = $data['email']; // Assurez-vous que la clé correcte est utilisée ici

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.mail.yahoo.com'; // Changez cela avec les détails de votre serveur SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'julienmans@yahoo.fr'; // Changez cela avec votre adresse e-mail
        $mail->Password = 'rtujpdytikaqlzvv'; // Changez cela avec votre mot de passe
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('julienmans@yahoo.fr', 'loire-kayak');
        $mail->addAddress($email, 'Code de vérification');

        $mail->Subject = 'Code de Vérification';
        $mail->Body    = "Vous pouvez utiliser le code FIRSTCOMMAND pour obtenir -20% sur votre première commande. Voici votre code de vérification : " . $code;
        $mail->send();
        echo 'L\'e-mail a été envoyé avec succès.';

        // Stockage du code de vérification dans la session
        $_SESSION['verification_code'] = $code;
?>
<html>
<head>
    <title>Vérification du Code</title>
</head>
<body>
    <h1>Vérification du Code</h1>
    <form method="post" action="core/envoiregister.php">
        <label>Entrez le code de vérification : </label>
        <input type="text" name="entered_code" required>
        <button type="submit" name="verify_code">Vérifier</button>
    </form>
</body>
</html>
<?php
    } catch (Exception $e) {
        echo "Erreur lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
    }
}
?>
