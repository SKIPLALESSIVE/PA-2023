<?php
define ("DB_HOST", "localhost");
define ("DB_NAME", "Loire");
define ("DB_USER", "root");
define ("DB_PWD", "fXXP2qsAhHNe");
define ("DB_PORT", "3306");
define ("DB_PREFIX", "ju_");
?>
