<?php 
include "functions.php"; 
include "../const.inc.php"; 
session_start(); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$date_debut = $_POST['date-start']; 
$date_fin = $_POST['date-end']; 
$emplacement = $_POST['ville']; 

$ListOfErrors=[]; 

// Vérifier les dates
if ($date_debut < date('Y-m-d') || $date_fin < date('Y-m-d')) {
    $ListOfErrors[] = 'Les dates ne peuvent pas être dans le passé.';
}

if ($date_debut > date('Y-m-d', strtotime('+2 years'))) {
    $ListOfErrors[] = 'Vous ne pouvez pas réserver plus de 2 ans à l\'avance.';
}

if (count($ListOfErrors) > 0) {
    // Stocker les erreurs en session
    $_SESSION['listOfErrors'] = $ListOfErrors;
    header('Location: ../ByAsk.php'); // Rediriger vers la page appropriée
    exit();
}

// Pas d'erreurs, effectuer la recherche
$connect = connectDB(); 
$queryPrepared = $connect->prepare("SELECT id, nom, emplacement, places, date_debut_fermeture, date_fin_fermeture, prix FROM ".DB_PREFIX."hotel WHERE emplacement=:emplacement");
$queryPrepared->execute(["emplacement" => $emplacement]);
$results = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);

// Vérifier si la date actuelle est entre le 15 juillet et le 15 août de chaque année
$currentDate = date('Y-m-d');
$year = date('Y'); // Obtenir l'année actuelle

if ($currentDate >= $year . '-07-15' && $currentDate <= $year . '-08-15') {
    // Augmenter les prix de 20%
    foreach ($results as &$hotel) {
        $hotel['prix'] *= 1.20;
    }
    unset($hotel); // Dissocier la référence de la dernière boucle
}

echo json_encode($results);
?>
