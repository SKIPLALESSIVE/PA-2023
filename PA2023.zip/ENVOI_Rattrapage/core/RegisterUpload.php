<?php 
include "functions.php"; 
include "../const.inc.php"; 
session_start();

if (isset($_SESSION['data'])) {
    $data = $_SESSION['data'];

    // Récupération des données depuis la session
    $gender = $data['gender'];
    $firstname = $data['firstname'];
    $lastname = $data['lastname'];
    $username = $data['username'];
    $birthday = $data['birthday'];
    $email = $data['email'];
    $pwd = $data['pwd'];

    // Connexion à la base de données
    $connection = connectDB();

    if (!$connection) {
        die("Erreur de connexion à la base de données");
    }

    // Requête préparée pour insérer les données dans la base de données
    $queryPrepared = $connection->prepare("INSERT INTO ".DB_PREFIX."user (gender, firstname, lastname, username, birthday, email, pwd) VALUES (:gender, :firstname, :lastname, :username, :birthday, :email, :pwd)");

    // Exécution de la requête
    $queryPrepared->execute([
        "gender" => $gender,
        "firstname" => $firstname,
        "lastname" => $lastname,
        "username" => $username,
        "birthday" => $birthday,
        "email" => $email,
        "pwd" => password_hash($pwd, PASSWORD_DEFAULT)
    ]);

    // Redirection vers la page de connexion
    header('Location: ../login.php');
    exit; // Arrêter l'exécution du script après la redirection
} else {
}
?>
