<?php
include "functions.php"; 
include "../const.inc.php"; 
session_start(); 


if (count($_POST) != 8
    || !isset($_POST['gender'])
    || empty($_POST['firstname'])
    || empty($_POST['lastname'])
    || empty($_POST['username'])
    || empty($_POST['birthday'])
    || empty($_POST['email'])
    || empty($_POST['pwd'])
    || empty($_POST['pwdConfirm'])
){
    $listOfErrors[] = "Il semblerait qu'une ou plusieurs des données nécessaires manquent à l'appel. Vérifiez vos informations.";
    $_SESSION["listOfErrors"] = $listOfErrors;
    header('location: ../register.php');
    exit; // Arrêter l'exécution du script après la redirection
}


$email = cleanEmail($_POST['email']);
$pwd = $_POST['pwd'];
$pwdConfirm = $_POST['pwdConfirm'];

// Vérification du format de l'e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $listOfErrors[] = "L'email est incorrect";
} else {
    // Connexion à la base de données
    $connection = connectDB();
    
    if (!$connection) {
        die("Erreur de connexion à la base de données");
    }

    // Requête préparée pour vérifier l'unicité de l'e-mail
    $queryPrepared = $connection->prepare("SELECT email FROM ".DB_PREFIX."user WHERE email=:email");
    $queryPrepared->execute(["email" => $email]);

    // Vérification des résultats
    $results = $queryPrepared->fetch();

    if (!empty($results)) {
        $listOfErrors[] = "L'email est déjà utilisé";
    }
}

// --> Complexité du mot de passe
if (strlen($pwd) < 8
    || !preg_match("#[a-z]#", $pwd)
    || !preg_match("#[A-Z]#", $pwd)
    || !preg_match("#[0-9]#", $pwd)
) {
    $listOfErrors[] = "Le mot de passe doit comporter au moins 8 caractères avec des minuscules, des majuscules et des chiffres";
}

// --> Confirmation du mot de passe
if ($pwd !== $pwdConfirm) {
    $listOfErrors[] = "La confirmation du mot de passe ne correspond pas";
}

//Nettoyage des données
$gender = $_POST['gender'];
$firstname = cleanFirstname($_POST['firstname']);
$lastname = cleanLastname($_POST['lastname']);
$username = cleanUsername($_POST['username']);
$birthday = $_POST['birthday'];

// --> Vérification du genre
$listGenders = [0, 1, 2];
if (!in_array($gender, $listGenders)) {
    $listOfErrors[] = "Le genre n'existe pas";
}


// --> Vérification du nom
if (strlen($lastname) < 2) {
    $listOfErrors[] = "Le nom doit comporter au moins 2 caractères";
}

if (preg_match("#[a-z]#", $lastname)  || preg_match("#[!@#$%^&*()_+=-]#", $lastname) || preg_match("#[0-9]#", $lastname)) {
    $listOfErrors[] = "Le nom ne doit contenir que des lettres.";
}

// --> Vérification du prénom
if (strlen($firstname) < 2) {
    $listOfErrors[] = "Le prénom doit comporter au moins 2 caractères";
}

if (!preg_match("#[a-z]#", $firstname)  || preg_match("#[!@#$%^&*()_+=-]#", $firstname) || preg_match("#[0-9]#", $firstname)) {
    $listOfErrors[] = "Le prénom ne doit contenir que des lettres.";
}

// --> Vérification du pseudo
if (strlen($username) < 3) {
    $listOfErrors[] = "Le pseudo doit comporter au moins 3 caractères";
}

//Vérification de la date de naissance
$birthdayExploded = explode("-", $birthday);

if (!checkdate($birthdayExploded[1], $birthdayExploded[2], $birthdayExploded[0])) {
    $listOfErrors[] = "Date de naissance incorrecte";
} else {
    //Vérification de l'âge
    $todaySecond = time();
    $birthdaySecond = strtotime($birthday);
    $ageSecond = $todaySecond - $birthdaySecond;
    $age = $ageSecond / 60 / 60 / 24 / 365.25;
    if ($age <= 6 || $age >= 99) {
        $listOfErrors[] = "Vous n'avez pas l'âge requis (entre 6 et 99 ans)";
    }
}

// --> Unicité du pseudo
$connection = connectDB();
$queryPrepared = $connection->prepare("SELECT username FROM ".DB_PREFIX."user WHERE username=:username");
$queryPrepared->execute([ "username" => $username ]);

$results = $queryPrepared->fetch();

if (!empty($results)) {
    $listOfErrors[] = "Le pseudo est déjà utilisé";
}

if (!empty($listOfErrors)) {
    $_SESSION['listOfErrors'] = $listOfErrors;
    header('location: ../register.php');
    exit; // Arrêter l'exécution du script après la redirection
} else {
    // On stocke les données dans la session pour les utiliser dans Verification.php
    $_SESSION['data'] = [
        'gender' => $gender,
        'firstname' => $firstname,
        'lastname' => $lastname,
        'username' => $username,
        'birthday' => $birthday,
        'email' => $email,
        'pwd' => $pwd,
        'pwdConfirm' => $pwdConfirm
    ];
    header('location: ../Verification.php');
    exit; // Arrêter l'exécution du script après la redirection
}
?>
