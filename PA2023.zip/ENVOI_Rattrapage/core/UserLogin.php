<?php
include 'functions.php';
include "../const.inc.php";

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!empty($_POST['login']) && !empty($_POST['pwd'])) {
    $email = cleanEmail($_POST['login']);
    $pwd = $_POST['pwd'];
    $connect = connectDB();
    $queryPrepared = $connect->prepare("SELECT id, pwd, status FROM ".DB_PREFIX."user WHERE email=:email");
    $queryPrepared->execute(["email"=>$email]);
    $results = $queryPrepared->fetch();

    if (!empty($results) && password_verify($pwd, $results["pwd"])) {
        $_SESSION['email'] = $email;
        $_SESSION['status'] = $results["status"];
        $_SESSION['id'] = $results['id']; 
        unset($_SESSION['numberOfTrying']);
        header("Location: ../index.php");
    } else {
        $_SESSION['listOfErrorsLogin'] = $listOfErrorsLogin;
        header('Location: ../login.php');
    }
}
?>
