<?php

session_start();

if(empty($_SESSION['email']) || empty($_SESSION['status'])){
    header('location: ../index.php');
    session_destroy();
} else {
    session_destroy();
}

header("Location: ../index.php");