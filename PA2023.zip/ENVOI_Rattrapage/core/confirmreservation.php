<?php
include "functions.php"; 
include "../const.inc.php"; 
session_start(); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected(); 

$datesStart = $_POST['dates_start'];
$datesEnd = $_POST['dates_end'];
$places = $_POST['places'];
$userid = $_SESSION['id']; 

$connect = connectDB();

foreach ($datesStart as $hotelKey => $dateStart) {
    $hotelId = (int) str_replace("hotel_", "", $hotelKey);
    $dateEnd = $datesEnd[$hotelKey];
    $numPlaces = (int) $places[$hotelKey];

    // Insérer les données de réservation dans la table
    $queryPrepared = $connect->prepare("INSERT INTO " . DB_PREFIX . "reservation (hotel_id, user_id, date_debut, date_fin, places) 
                                        VALUES (:hotel_id, :user_id, :date_debut, :date_fin, :places)");
    $queryPrepared->bindValue(':hotel_id', $hotelId, PDO::PARAM_INT);
    $queryPrepared->bindValue(':user_id', $userid, PDO::PARAM_INT);
    $queryPrepared->bindValue(':date_debut', $dateStart, PDO::PARAM_STR);
    $queryPrepared->bindValue(':date_fin', $dateEnd, PDO::PARAM_STR);
    $queryPrepared->bindValue(':places', $numPlaces, PDO::PARAM_INT);
    $queryPrepared->execute();
}

// Rediriger ou afficher un message de confirmation
echo "Réservation effectuée avec succès!";
?>
