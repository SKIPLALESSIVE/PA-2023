


<?php 
    include "functions.php"; 
    include "../const.inc.php"; 
    session_start(); 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    print_r($_POST); 
    
        $hotel_liste = $_POST['hotelIds']; 
        $packDescription = $_POST['packDescription']; 
        $nom = $_POST['packName'];    
        $connect = connectDB(); 
        $queryPrepared = $connect->prepare("INSERT INTO " . DB_PREFIX . "pack (hotel_all, description,nom) VALUES (:hotel_liste, :description,:nom)"); 
        $queryPrepared->execute([
            'hotel_liste' => $hotel_liste,
            'description' => $packDescription,
            'nom' => $nom
        ]);

        echo "Nouveau pack créé avec succès !";
?>
