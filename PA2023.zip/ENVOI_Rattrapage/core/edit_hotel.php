<?php
include 'functions.php';
include "../const.inc.php";

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected();
$hotelId = $_GET['id'];

// Récupérer les informations de l'hôtel à partir de la base de données
$connect = connectDB();
$query = "SELECT id, emplacement, places, rénovation, nom, date_debut_fermeture, date_fin_fermeture, prix FROM " . DB_PREFIX . "hotel WHERE id = :id";
$queryPrepared = $connect->prepare($query);
$queryPrepared->execute(array(':id' => $hotelId));
$hotelInfo = $queryPrepared->fetch(PDO::FETCH_ASSOC);

if (!$hotelInfo) {
    echo "Hôtel non trouvé.";
    exit;
}

// Traitement du formulaire de modification d'hôtel
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['emplacement']) && !empty($_POST['places']) && isset($_POST['renovation'])) {
    $emplacement = $_POST['emplacement'];
    $places = $_POST['places'];
    $nom = $_POST['nom'];
    $renovation = ($_POST['renovation'] == '1') ? '1' : '0';
    $dateDebutFermeture = !empty($_POST['date_debut_fermeture']) ? $_POST['date_debut_fermeture'] : null;
    $dateFinFermeture = !empty($_POST['date_fin_fermeture']) ? $_POST['date_fin_fermeture'] : null;
    $prix = $_POST['prix']; // Récupération du prix

    // Mettre à jour les informations de l'hôtel dans la base de données, y compris les dates de fermeture et le prix
    $updateQuery = "UPDATE " . DB_PREFIX . "hotel SET emplacement = :emplacement, places = :places, nom = :nom, rénovation = :renovation, date_debut_fermeture = :date_debut_fermeture, date_fin_fermeture = :date_fin_fermeture, prix = :prix WHERE id = :id";
    $updateQueryPrepared = $connect->prepare($updateQuery);
    $updateQueryPrepared->execute(array(
        ':emplacement' => $emplacement,
        ':places' => $places,
        ':nom' => $nom,
        ':renovation' => $renovation,
        ':date_debut_fermeture' => $dateDebutFermeture,
        ':date_fin_fermeture' => $dateFinFermeture,
        ':id' => $hotelId,
        ':prix' => $prix // Mise à jour du prix
    ));

    // Rediriger vers la page d'index après la modification
    header("Location: ../index.php");
}

// Si le formulaire est soumis, récupérer les dates de début et de fin
$date_debut = isset($_POST['date_debut']) ? $_POST['date_debut'] : null;
$date_fin = isset($_POST['date_fin']) ? $_POST['date_fin'] : null;

// Calculer le taux de remplissage
$taux_remplissage = 0;

if ($date_debut && $date_fin) {
    $queryReservation = "SELECT SUM(places) AS total_places FROM " . DB_PREFIX . "reservation WHERE hotel_id = :hotel_id AND date_debut >= :date_debut AND date_fin <= :date_fin";
    $queryReservationPrepared = $connect->prepare($queryReservation);
    $queryReservationPrepared->execute(array(':hotel_id' => $hotelId, ':date_debut' => $date_debut, ':date_fin' => $date_fin));
    $reservationInfo = $queryReservationPrepared->fetch(PDO::FETCH_ASSOC);

    $totalPlaces = $hotelInfo['places'];
    $reservedPlaces = $reservationInfo['total_places'];
    $taux_remplissage = ($totalPlaces > 0) ? ($reservedPlaces / $totalPlaces) * 100 : 0;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Modifier un Hôtel</title>
    <link href="../css/styles.css" rel="stylesheet"/>
          <link href="../css/perso.css" rel="stylesheet" />
</head>
<body>

<h1 class="center-text blue">Modifier un Hôtel</h1>
<div class= "center-text page-section cta-ua white"> 
    <div class="mb-4"> 
<!-- Formulaire de modification d'hôtel -->
<form method="POST" action="">
    <label for="emplacement">Emplacement :</label>
    <select id="emplacement" name="emplacement" required>
        <option value="Orléans" <?php if ($hotelInfo['emplacement'] == 'Orléans') echo 'selected'; ?>>Orléans</option>
        <option value="Nantes" <?php if ($hotelInfo['emplacement'] == 'Nantes') echo 'selected'; ?>>Nantes</option>
        <option value="Blois" <?php if ($hotelInfo['emplacement'] == 'Blois') echo 'selected'; ?>>Blois</option>
        <option value="Saint-Florent-Le-Vieil" <?php if ($hotelInfo['emplacement'] == 'Saint-Florent-Le-Vieil') echo 'selected'; ?>>Saint-Florent-Le-Vieil</option>
        <option value="Thoureil" <?php if ($hotelInfo['emplacement'] == 'Thoureil') echo 'selected'; ?>>Thoureil</option>
        <option value="Cunault" <?php if ($hotelInfo['emplacement'] == 'Cunault') echo 'selected'; ?>>Cunault</option>
        <option value="Béhuard" <?php if ($hotelInfo['emplacement'] == 'Béhuard') echo 'selected'; ?>>Béhuard</option>
        <option value="Saymur" <?php if ($hotelInfo['emplacement'] == 'Saumur') echo 'selected'; ?>>Saumur</option>
        <option value="Tours" <?php if ($hotelInfo['emplacement'] == 'Tours') echo 'selected'; ?>>Tours</option>
        <option value="Ambroise" <?php if ($hotelInfo['emplacement'] == 'Ambroise') echo 'selected'; ?>>Ambroise</option>
        <option value="Montsoreau" <?php if ($hotelInfo['emplacement'] == 'Montsoreau') echo 'selected'; ?>>Montsoreau</option>
        <option value="Fleury" <?php if ($hotelInfo['emplacement'] == 'Fleury') echo 'selected'; ?>>Fleury</option>
        <option value="Sancerre" <?php if ($hotelInfo['emplacement'] == 'Sancerre') echo 'selected'; ?>>Sancerre</option>
        <option value="Apremont" <?php if ($hotelInfo['emplacement'] == 'Apremont') echo 'selected'; ?>>Apremont</option>

    </select><br>
    <label for="places">Places :</label>
    <input type="number" name="places" value="<?php echo $hotelInfo['places']; ?>" required><br>
    <label for="nom">Nom :</label>
    <input type="text" name="nom" value="<?php echo $hotelInfo['nom']; ?>" required><br>
    <label for="prix">Prix :</label>
    <input type="number" name="prix" value="<?php echo $hotelInfo['prix']; ?>" required><br> <!-- Champ pour le prix -->
    <label for="renovation">Rénovation :</label>
    <input type="radio" name="renovation" value="1" <?php if ($hotelInfo['rénovation'] == '1') echo 'checked'; ?>> Oui
    <input type="radio" name="renovation" value="0" <?php if ($hotelInfo['rénovation'] == '0') echo 'checked'; ?>> Non<br>
    <label for="date_debut_fermeture">Date de début de fermeture :</label>
    <input type="date" name="date_debut_fermeture" value="<?php echo $hotelInfo['date_debut_fermeture']; ?>"><br>
    <label for="date_fin_fermeture">Date de fin de fermeture :</label>
    <input type="date" name="date_fin_fermeture" value="<?php echo $hotelInfo['date_fin_fermeture']; ?>"><br>
    <input type="submit" class="logout-button"value="Modifier l'hôtel">
</form>
</div> 
<!-- Lien vers la page de graphique -->
<div>
    <h2>Graphique de Remplissage</h2>
    <form method="GET" action="graph.php">
        <input type="hidden" name="hotelId" value="<?php echo $hotelId; ?>">
        <label for="date_debut">Date de début :</label>
        <input type="date" name="date_debut" required><br>
        <label for="date_fin">Date de fin :</label>
        <input type="date" name="date_fin" required><br>
        <input type="submit"  class= "btn btn-primary-A" value="Afficher le graphique">
    </form>

    <img src="../assets/img/hotel/<?php print($hotelId)?>.png">
</div>

<form action="upload_img.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="hotel_id" value="<?php echo($hotelId)?>">
    <input type="file" class="logout-button"name="image" accept=".png">
    <input type="submit" class="logout-button" value="Télécharger">
</form>
</div> 
</body>
</html>
