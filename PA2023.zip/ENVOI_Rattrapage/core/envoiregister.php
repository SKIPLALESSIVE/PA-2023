<?php
include "functions.php";
include "../const.inc.php";
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$enteredCode = $_POST['entered_code']; // Utilisez "entered_code" au lieu de "entered_core"
$verifcode = $_SESSION['verification_code'];
$data = $_SESSION['data'];
$gender = $data['gender'];
$firstname = $data['firstname'];
$lastname = $data['lastname'];
$username = $data['username'];
$birthday = $data['birthday'];
$email = $data['email'];
$pwd = $data['pwd'];

$connection = connectDB();
if ($enteredCode == $verifcode) {
    $queryPrepared = $connection->prepare("INSERT INTO " . DB_PREFIX . "user (gender, firstname, lastname, username, birthday, email, pwd) VALUES (:gender, :firstname, :lastname, :username, :birthday, :email, :pwd)");

    // Exécution de la requête
    if ($queryPrepared->execute([
        "gender" => $gender,
        "firstname" => $firstname,
        "lastname" => $lastname,
        "username" => $username,
        "birthday" => $birthday,
        "email" => $email,
        "pwd" => password_hash($pwd, PASSWORD_DEFAULT)
    ])) { // Ajout de la condition manquante
        echo "Enregistrement réussi."; // Message de succès
        session_destroy(); 
        
    } else {
        echo "Erreur lors de l'enregistrement."; // Message d'erreur
    }
}
?>
