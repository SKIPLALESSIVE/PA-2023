<?php
include 'functions.php';
include "../const.inc.php";

$hotelId = $_GET['hotelId'];

// Récupérer les informations de l'hôtel à partir de la base de données
$connect = connectDB();
$query = "SELECT id, places FROM " . DB_PREFIX . "hotel WHERE id = :id";
$queryPrepared = $connect->prepare($query);
$queryPrepared->execute(array(':id' => $hotelId));
$hotelInfo = $queryPrepared->fetch(PDO::FETCH_ASSOC);

if (!$hotelInfo) {
    echo "Hôtel non trouvé.";
    exit;
}

// Récupérer les dates de début et de fin depuis la requête GET
$date_debut = isset($_GET['date_debut']) ? $_GET['date_debut'] : null;
$date_fin = isset($_GET['date_fin']) ? $_GET['date_fin'] : null;

// Calculer le taux de remplissage
$taux_remplissage = 0;

if ($date_debut && $date_fin) {
    $queryReservation = "SELECT SUM(places) AS total_places FROM " . DB_PREFIX . "reservation WHERE hotel_id = :hotel_id AND date_debut >= :date_debut AND date_fin <= :date_fin";
    $queryReservationPrepared = $connect->prepare($queryReservation);
    $queryReservationPrepared->execute(array(':hotel_id' => $hotelId, ':date_debut' => $date_debut, ':date_fin' => $date_fin));
    $reservationInfo = $queryReservationPrepared->fetch(PDO::FETCH_ASSOC);

    $totalPlaces = $hotelInfo['places'];
    $reservedPlaces = $reservationInfo['total_places'];
    $taux_remplissage = ($totalPlaces > 0) ? ($reservedPlaces / $totalPlaces) * 100 : 0;
}

// Générer le graphique de remplissage en utilisant les données de réservation
$graph_width = 800; // Largeur du graphique
$graph_height = 600; // Hauteur du graphique
$image = imagecreatetruecolor($graph_width, $graph_height);
$background_color = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 0, 0, 0);
$fill_color = imagecolorallocate($image, 0, 0, 255); // Couleur bleue
$empty_color = imagecolorallocate($image, 0, 128, 0); // Couleur verte

// Remplir le fond avec la couleur blanche
imagefilledrectangle($image, 0, 0, $graph_width, $graph_height, $background_color);

// Dessiner le camembert vide
$start_angle = 0;
$end_angle = 360;
$empty_angle = 360;
imagefilledarc($image, $graph_width / 2, $graph_height / 2, $graph_width - 20, $graph_height - 20, $start_angle, $empty_angle, $empty_color, IMG_ARC_PIE);
imagearc($image, $graph_width / 2, $graph_height / 2, $graph_width - 20, $graph_height - 20, $start_angle, $empty_angle, $text_color);

// Dessiner le camembert rempli
$occupied_angle = ($reservedPlaces / $totalPlaces) * 360;
imagefilledarc($image, $graph_width / 2, $graph_height / 2, $graph_width - 20, $graph_height - 20, $start_angle, $occupied_angle, $fill_color, IMG_ARC_PIE);
imagearc($image, $graph_width / 2, $graph_height / 2, $graph_width - 20, $graph_height - 20, $start_angle, $occupied_angle, $text_color);

// Ajouter le texte en haut du graphique
$title = "Graph de remplissage de l'hotel";
$title_width = imagefontwidth(5) * strlen($title);
$title_x = ($graph_width - $title_width) / 2;
$title_y = 30; // Modifier la valeur pour ajuster la position verticale du titre
imagestring($image, 5, $title_x, $title_y, $title, $text_color);

// Afficher le graphique de remplissage
header("Content-type: image/png");
imagepng($image);
imagedestroy($image);
?>
