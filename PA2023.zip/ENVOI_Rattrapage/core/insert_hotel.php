<?php
include 'functions.php';
include "../const.inc.php";

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Traitement du formulaire d'ajout d'hôtel
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['emplacement']) && !empty($_POST['places']) && isset($_POST['renovation'])) {
    $emplacement = $_POST['emplacement'];
    $places = $_POST['places'];
    $name = $_POST['name'];
    $renovation = $_POST['renovation'];
    $prix = $_POST['prix']; 
    // Connectez-vous à la base de données
    $connect = connectDB();
    
    // Préparez et exécutez l'insertion
    $query = "INSERT INTO " . DB_PREFIX . "hotel (emplacement, places, nom, rénovation,prix) VALUES (:emplacement, :places, :nom, :renovation, :prix)";
    $queryPrepared = $connect->prepare($query);
    
    // Exécution de la requête avec les paramètres
    $queryPrepared->execute([
        ':emplacement' => $emplacement,
        ':places' => $places,
        ':nom' => $name,
        ':renovation' => $renovation,
        ':prix' => $prix
    ]);
    
    // Redirigez vers la page index.php après l'insertion
    header("Location: ../index.php");
}



?>
