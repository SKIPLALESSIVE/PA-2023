<?php
include "functions.php"; 
include "../const.inc.php"; 
session_start(); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$packId = $_POST['pack_id'];

$connect = connectDB(); 
$queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "pack WHERE id = :pack_id");
$queryPrepared->bindValue(':pack_id', $packId, PDO::PARAM_INT);
$queryPrepared->execute();
$pack = $queryPrepared->fetch(PDO::FETCH_ASSOC);

$hotelIds = str_replace(" ", "", $pack['hotel_all']);
$hotelIdsArray = explode('e', $hotelIds); // Utilisation de "e" comme séparateur
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sélection des Dates et Places</title>
    <link href="../css/styles.css" rel="stylesheet"/>
          <link href="../css/perso.css" rel="stylesheet" />
</head>
<body>
    <h1 class="center-text white">Sélection des Dates et Places pour les Hôtels du Pack</h1>

    <form action="confirmreservation.php" method="post">
        <input type="hidden" name="pack_id" value="<?php echo $packId; ?>">
        <section class="page-section cta center-text">
        <?php
        foreach ($hotelIdsArray as $hotelId) {
            $queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "hotel WHERE id = :hotel_id"); 
            $queryPrepared->bindValue(':hotel_id', $hotelId, PDO::PARAM_INT);
            $queryPrepared->execute();
            $hotel = $queryPrepared->fetch(PDO::FETCH_ASSOC);

            if ($hotel) {
                echo "<h2>{$hotel['nom']}</h2>";
                echo "<p>Emplacement: {$hotel['emplacement']}</p>";
                echo "<p>Places disponibles: {$hotel['places']}</p>";
                echo "<p>Prix: {$hotel['prix']}</p>";
                
                echo "<label for='date_start_hotel_{$hotelId}'>Date de début:</label>";
                echo "<input type='date' name='dates_start[hotel_{$hotelId}]' required><br>";
                
                echo "<label for='date_end_hotel_{$hotelId}'>Date de fin:</label>";
                echo "<input type='date' name='dates_end[hotel_{$hotelId}]' required><br>";

                echo "<label for='places_hotel_{$hotelId}'>Nombre de places:</label>";
                echo "<input type='number' name='places[hotel_{$hotelId}]' min='1' max='{$hotel['places']}' required><br><br>";
            }
        }
        ?>

        <button type="submit" class="btn btn-primary">Confirmer la Réservation</button>
    </form>
    </section>
</body>
</html>
