<?php 
include "functions.php"; 
include "../const.inc.php"; 
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected(); 

$connect = connectDB(); 
$queryPrepared = $connect->prepare("SELECT id, hotel_id, date_debut, date_fin, places FROM " . DB_PREFIX ."reservation WHERE user_id = :user_id AND is_payed = 0"); 
$queryPrepared->bindValue(':user_id', $_SESSION['id'], PDO::PARAM_INT);
$queryPrepared->execute(); 
$reservations = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);
$totalAmount = 0; 

$promoCodeValid = 0; // Initialiser à 0 par défaut

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reservation_ids']) && is_array($_POST['reservation_ids'])) {
        $reservationIds = $_POST['reservation_ids'];

        // Vérifier si le transport de bagages est coché
        $baggageTransport = isset($_POST['baggage_transport']) ? 1 : 0;

        // Mettre à jour la colonne baggage_transport pour les réservations sélectionnées
        $updateQuery = $connect->prepare("UPDATE " . DB_PREFIX ."reservation SET baggage_transport = :baggage_transport WHERE id = :reservation_id");
        
        foreach ($reservationIds as $reservationId) {
            $updateQuery->bindValue(':baggage_transport', $baggageTransport, PDO::PARAM_INT);
            $updateQuery->bindValue(':reservation_id', $reservationId, PDO::PARAM_INT);
            $updateQuery->execute();
        }

        // Redirection ou message de succès
        header("Location: payallreservations.php");
        exit();
    }
}

if (isset($_POST['promo_code']) && !empty($_POST['promo_code'])) {
    $promoCode = $_POST['promo_code'];
    
    // Vérifier le code de promotion
    $queryPrepared = $connect->prepare("SELECT first_code FROM " . DB_PREFIX ."user WHERE id = :user_id"); 
    $queryPrepared->bindValue(':user_id', $_SESSION['id'], PDO::PARAM_INT);
    $queryPrepared->execute(); 
    $user = $queryPrepared->fetch(PDO::FETCH_ASSOC);
    
    if ($user['first_code'] == 0 && $promoCode == 'FIRSTCOMMAND') {
        // Mettre à jour le champ first_code à 1 pour ne plus permettre l'utilisation future du code
        $updateQuery = $connect->prepare("UPDATE " . DB_PREFIX ."user SET first_code = 1 WHERE id = :user_id");
        $updateQuery->bindValue(':user_id', $_SESSION['id'], PDO::PARAM_INT);
        $updateQuery->execute();
        
        $promoCodeValid = 1; // Si le code est valide, passer à 1
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tableau de bord</title>
    <link href="../css/styles.css" rel="stylesheet"/>
          <link href="../css/perso.css" rel="stylesheet" />

</head>
<body>
    <?php if (!isset($_SESSION['listOfErrors']) || empty($_SESSION['listOfErrors'])) : ?>

    <?php else : ?>
        <?php unset($_SESSION['listOfErrors']); ?>
    <?php endif; ?>

    <?php if (count($reservations) > 0) : ?>
        <h1 class="site-heading-upper mb-3 changePai center-text"> Réservation à payer </h2>
<div class="row-ua">
  <section class="page-section cta-custom">
    <div class="cta-custom cta-inner">
        <form action="payallreservations.php" method="post">
            <label for="promo_code">Code de promotion:</label>
            <input type="text" name="promo_code" id="promo_code">
            <button type="submit" class="btn btn-primary">Appliquer le code</button>
            <input type="hidden" name="promo_code_valid" value="<?php echo $promoCodeValid; ?>">
            <br><br>
            <table>
                <tr>
                    <th>ID Réservation</th>
                    <th>ID Hôtel</th>
                    <th>Date de début</th>
                    <th>Date de fin</th>
                    <th>Places réservées</th>
                    <th>Prix total</th>
                    <th>Payer</th>
                </tr>
                <?php foreach ($reservations as $reservation) : 
                    $queryPrepared = $connect->prepare("SELECT prix FROM " . DB_PREFIX ."hotel WHERE id = :id"); 
                    $queryPrepared->bindValue(':id', $reservation['hotel_id'], PDO::PARAM_INT);
                    $queryPrepared->execute(); 
                    $hotel = $queryPrepared->fetch(PDO::FETCH_ASSOC);
                    
                    if ($hotel) {
                        $prixUnitaire = $hotel['prix'];
                        $prixTotal = $prixUnitaire * $reservation['places'];
                        $totalAmount += $prixTotal;
                    }
                    ?>
                    <tr>
                        <td><?php echo $reservation['id']; ?></td>
                        <td><?php echo $reservation['hotel_id']; ?></td>
                        <td><?php echo $reservation['date_debut']; ?></td>
                        <td><?php echo $reservation['date_fin']; ?></td>
                        <td><?php echo $reservation['places']; ?></td>
                        <td><?php echo $prixTotal; ?></td>
                        <td>
                            <input type="checkbox" name="reservation_ids[]" value="<?php echo $reservation['id']; ?>">
                        </td>
                    </tr>
                </div> 
                </section> 
                
                </div>
                <?php endforeach; ?>
            </table>
            
            <!-- Champs pour le transport de bagages -->
            <label for="baggage_transport">Transport de bagages:</label>
            <input type="checkbox" name="baggage_transport" id="baggage_transport" value="1">
            
            <input type="hidden" name="total_amount" value="<?php echo $totalAmount; ?>">
            <p>Total à payer: <?php echo $totalAmount; ?></p>
            <button type="submit" class="btn btn-primary"> Payer </button>    
        </form>
        <a href="../index.php" class="logout-button">retour a l'accueil</a>
    <?php else : ?>
        <p>Aucune réservation à payer trouvée.</p>
        <a href="../index.php" class="logout-button">retour a l'accueil</a>
    <?php endif; ?>
</body>
</html>
