<?php 
include "functions.php"; 
include "../const.inc.php"; 
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
redirectIfNotConnected(); 

$reservationPOST = $_POST['reservation_ids']; 
$connect = connectDB(); 
$queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX ."user WHERE id = :user_id"); 
$queryPrepared->bindValue(':user_id', $_SESSION['id'], PDO::PARAM_INT);
$queryPrepared->execute(); 
$reservation = $queryPrepared->fetch(PDO::FETCH_ASSOC);

foreach ($reservationPOST as $id) {
    $queryPrepared = $connect->prepare("UPDATE " . DB_PREFIX . "reservation SET is_payed = 1 WHERE id = :id"); 
    $queryPrepared->bindValue(':id', $id, PDO::PARAM_INT);
    $queryPrepared->execute();
}

// Récupérer la valeur de l'option de transport de bagages
$baggageTransport = isset($_POST['baggage_transport']) ? $_POST['baggage_transport'] : 0;

// Mettre à jour l'option de transport de bagages pour les réservations sélectionnées
foreach ($reservationPOST as $id) {
    $queryPrepared = $connect->prepare("UPDATE " . DB_PREFIX . "reservation SET baggage_transport = :baggage WHERE id = :id"); 
    $queryPrepared->bindValue(':id', $id, PDO::PARAM_INT);
    $queryPrepared->bindValue(':baggage', $baggageTransport, PDO::PARAM_INT);
    $queryPrepared->execute();
}

echo "Réservations payées avec succès";
?>
<html>
    <head>
<link href="../css/styles.css" rel="stylesheet"/>
          <link href="../css/perso.css" rel="stylesheet" />
</head>
<button onclick="window.location.href = '../index.php';" class="btn btn-primary">Retourner à l'accueil</button>
</html>