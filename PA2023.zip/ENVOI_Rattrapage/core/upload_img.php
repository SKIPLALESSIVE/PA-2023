<?php 
include "functions.php";
include "../const.inc.php"; 
session_start(); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$targetDir="../assets/img/hotel/"; 
$hotelId = $_POST['hotel_id'] . ".png"; 

$fileToDelete = $targetDir . $hotelId;

if (file_exists($fileToDelete)) {
    if (unlink($fileToDelete)) {
        echo "Le fichier a été supprimé avec succès.";
    } else {
        echo "Impossible de supprimer le fichier.";
    }
} else {
    echo "Le fichier n'existe pas.";
}

if (move_uploaded_file($_FILES['image']['tmp_name'], $fileToDelete)) {
    echo('Téléchargé avec succès');
} else {
    echo('Erreur lors du téléchargement');
}

