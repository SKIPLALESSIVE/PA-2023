
<?php
$isTablet = false;

// Détecter si l'utilisateur accède depuis une tablette en utilisant l'agent utilisateur
$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
$isTablet = (strpos($userAgent, 'ipad') !== false) || (strpos($userAgent, 'android') !== false && strpos($userAgent, 'mobile') === false);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Dessinnez la loire ! </title>
    <link href="css/styles.css" rel="stylesheet"/>
          <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
    <img src="assets/img/loire.jpg" alt="l'image ne se charge pas !" class="intro-img img-fluid mb-3 mb-lg-0 rounded ms-lg-5"> 
    <?php if ($isTablet) : ?>
        <div class="center-text"> 
            <section class="page section cta">  
        <h2 class="center-text white">Dessinez ici :</h2>
        <canvas id="drawingCanvas" width="400" height="400" style="border: 1px solid black;"></canvas>
        <button id="saveButton" class="btn btn-primary">Enregistrer</button>
        <script>
            // Récupérer le canevas et le contexte de dessin
            var canvas = document.getElementById('drawingCanvas');
            var context = canvas.getContext('2d');

            var isDrawing = false;
            var lastX = 0;
            var lastY = 0;

            canvas.addEventListener('mousedown', startDrawing);
            canvas.addEventListener('mousemove', draw);
            canvas.addEventListener('mouseup', stopDrawing);
            canvas.addEventListener('mouseout', stopDrawing);
            
            // Gestion des événements tactiles pour simuler l'affichage du curseur
            canvas.addEventListener('touchstart', function (e) {
                context.strokeStyle = 'rgba(0, 0, 0, 0.5)';
                startDrawing(e.touches[0]);
            });

            canvas.addEventListener('touchend', stopDrawing);

            // Fonction pour démarrer le dessin
            function startDrawing(e) {
                isDrawing = true;
                lastX = e.pageX - canvas.offsetLeft;
                lastY = e.pageY - canvas.offsetTop;
            }

            // Fonction pour dessiner
            function draw(e) {
                if (!isDrawing) return;
                context.lineJoin = 'round';
                context.lineWidth = 5;
                context.beginPath();
                context.moveTo(lastX, lastY);
                context.lineTo(e.offsetX, e.offsetY);
                context.closePath();
                context.stroke();
                lastX = e.offsetX;
                lastY = e.offsetY;
            }

            // Fonction pour arrêter le dessin
            function stopDrawing() {
                isDrawing = false;
                context.strokeStyle = 'black'; // Réinitialiser la couleur du stylo
            }

            // Enregistrer le dessin en tant qu'image PNG
            document.getElementById('saveButton').addEventListener('click', function() {
                var imgData = canvas.toDataURL('image/png');
                var link = document.createElement('a');
                link.href = imgData;
                link.download = 'mon_dessin.png';
                link.click();
            });
        </script>
    <?php else: ?>
        <p>Cet easter egg est disponible uniquement sur des tablettes.</p>
    <?php endif; ?>
    </div> 
    </section>
</body>
</html>
