<?php 

include "core/functions.php"; 
include "const.inc.php"; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Page non trouvée</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
    <h1>Erreur 404 - Page non trouvée</h1>
    <p>Désolé, la page que vous recherchez n'existe pas.</p>

    <?php
    ?>

    <script>
        setTimeout(function() {
            window.location.href = "index.php"; 
        }, 5000); 
    </script>
</body>
</html>
