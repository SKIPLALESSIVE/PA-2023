 <?php 
 include "template/header.php"; 
 include "core/functions.php"; 
 include "const.inc.php"; 

 session_start(); 

 ?>
    <body>
        <header>
            <h1 class="site-heading text-center text-faded d-none d-lg-block">
                <span class="blue site-heading-upper mb-3"> Loire Kayak, spécialistes depuis 1800</span>
                <span class="site-heading-lower">Experts de votre bonheur</span>
            </h1>
        </header>
        <!-- Navigation-->
        <?php if (isConnected() && $_SESSION['status']!= 1) {
    include "template/navbarB.php"; 
            } else if (isConnected() && $_SESSION['status']== 1) {
         include "template/navbarA.php"; 
             } else {
                include "template/navbar.php"; }  ?> 
        <section class="page-section cta">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <div class="cta-inner bg-faded text-center rounded">
                            <h2 class="section-heading mb-4">
                                <span class="section-heading-upper">Une expérience inoubliable</span>

                            </h2>
                            <p class="mb-0">L'une des particularités de Loire Kayak est notre engagement envers la préservation de l'environnement. Nous sommes fiers d'être une entreprise respectueuse de la nature, et c'est pourquoi nous encourageons activement le tourisme responsable et durable. En explorant la Loire avec nous, vous contribuez à la préservation de cet écosystème unique tout en découvrant ses merveilles préservées.</p>
                            <div class="intro-button mx-auto"><a class="btn btn-primary btn-xl" href="register.php">Créez votre compte maintenant</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="page-section clearfix">
    <div class="container">
        <div class="intro d-lg-flex justify-content-between align-items-center">
            <div class="intro-text text-center bg-faded p-5 rounded me-lg-5">
                <h2 class="section-heading mb-4">
                    <span class="section-heading-upper">un havre de paix</span>
                </h2>
                <p class="mb-3">Bienvenue chez Loire Kayak, votre porte d'entrée vers une aventure inoubliable le long du majestueux fleuve Loire. Nous sommes fiers de vous offrir une expérience unique en son genre, où la beauté de la nature se mêle harmonieusement à l'excitation de l'aventure en plein air. Si vous cherchez à vivre des moments de détente, d'émerveillement et de déconnexion totale du quotidien, ne cherchez pas plus loin !</p>
                <div class="intro-button mx-auto"><a class="btn btn-primary btn-xl" href="#!">Faites votre iténaire personnalisé</a></div>
            </div>
            <img class="intro-img img-fluid mb-3 mb-lg-0 rounded ms-lg-5" src="assets/img/couple-kayak-riviere.jpg" alt="Oups, ça va revenir..." />
        </div>
    </div>
</section>


        <section class="page-section cta">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <div class="cta-inner bg-faded text-center rounded">
                            <h2 class="section-heading mb-4">
                                <span class="section-heading-upper"> Vous êtes entre de bonnes mains</span>
                            </h2>
                            <p class="mb-0">Notre équipe dévouée a établi des partenariats solides avec des hôtels réputés le long de la Loire, garantissant des hébergements de qualité qui répondent à vos besoins et à votre budget. Que vous préfériez séjourner dans des hôtels pittoresques au charme authentique ou dans des établissements plus luxueux offrant une vue imprenable sur le fleuve, nous avons des options pour tous les goûts.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="page-section clearfix">
    <div class="container">
        <div class="intro d-lg-flex justify-content-between align-items-center">
            <div class="intro-text text-center bg-faded p-5 rounded me-lg-5">
                <h2 class="section-heading mb-4">
                    <span class="section-heading-upper">sensationns fortes</span>
                </h2>
                <p class="mb-3">Que vous soyez amoureux de la nature ou de sensations fortes, nous avons tout ce qu'il vous faut, le tout réservable en quelques clics. </p>
                <div class="intro-button mx-auto"><a class="btn btn-primary btn-xl" href="#!"> Voir nos offres préfaites</a></div>
            </div>
            <img class="intro-img img-fluid mb-3 mb-lg-0 rounded ms-lg-5" src="assets/img/rafting.jpg" alt="Oups, ça va revenir..." />
        </div>
    </div>
</section>
        <footer class="footer text-faded text-center py-5">
            <div class="container"><p class="m-0 small">Mansiat Julien &copy; Rattrapage PA 2023</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
