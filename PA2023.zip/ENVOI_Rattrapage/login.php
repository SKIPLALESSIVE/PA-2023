<?php
include "template/header.php"; 
session_start();
?>
<body>
    <header>
        <h1 class="site-heading text-center text-faded d-none d-lg-block">
            <span class="site-heading-upper text-primary mb-3">LOIRE KAYAK</span>
            <span class="site-heading-lower">Se connecter à l'espace client </span>
        </h1>
    </header>
    <!-- Navigation-->
    <?php include "template/navbar.php"; ?> 
    <section class="page-section cta">
        <div class="container">
            <form id="userlogin" action="core/UserLogin.php" method="POST">
                <?php
                if (!isset($_SESSION['listOfErrorsLogin']) || empty($_SESSION['listOfErrorsLogin'])) {
                    echo ('<h2 class="textDuckBlueDark mt-0">Inscription !</h2>');
                } else {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <h1>Attention</h1>
                            <?php
                            foreach ($_SESSION['listOfErrorsLogin'] as $error) {
                                echo ("<li>" . $error . "</li>");
                            }
                            unset($_SESSION['listOfErrorsLogin']);
                            ?>
                        </ul>
                    </div>
                <?php
                }
                ?>
                
                <div class="row">
                    <div class="row mb-4">
                    <div class="col-lg-6">
                        <form id="userlogin" action="core/UserLogin.php" method=POST> 
                        <input type="email" class="form-control" name="login" placeholder="Votre email" required="required">
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-lg-6">
                            <input type="password" class="form-control" name="pwd" placeholder="Votre Mot De Passe" required="required">
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary " type='submit'> Se connecter </button>
            </form>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container"><p class="m-0 small">Copyright &copy; Your Website 2023</p></div>
    </footer>
   
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>
