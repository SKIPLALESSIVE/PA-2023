<?php
include "template/header.php"; 

session_start();
?>
<body>
    <header>
        <h1 class="site-heading text-center text-faded d-none d-lg-block">
            <span class="site-heading-upper text-primary mb-3">LOIRE KAYAK</span>
            <span class="site-heading-lower">Inscription</span>
        </h1>
    </header>
    <!-- Navigation-->
    <?php include "template/navbar.php"; ?> 
    <section class="page-section cta">
        <div class="container">
            <form id="userRegister" action="core/UploadData.php" method="POST">
                <?php
                if (!isset($_SESSION['listOfErrors']) || empty($_SESSION['listOfErrors'])) {
                    echo ('<h2 class="textDuckBlueDark mt-0">Inscription !</h2>');
                } else {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <h1>Attention</h1>
                            <?php
                            foreach ($_SESSION['listOfErrors'] as $error) {
                                echo ("<li>" . $error . "</li>");
                            }
                            unset($_SESSION['listOfErrors']);
                            ?>
                        </ul>
                    </div>
                <?php
                }
                ?>
                
                <div class="row">
                    <div class="col-lg-6">
                        <input type="radio" class="form-check-input" value="0" checked="checked" name="gender" id="genderM">
                        <label for="genderM" class="form-label"> M.</label> 

                        <input type="radio" class="form-check-input" value="1" name="gender" id="genderMme">
                        <label for="genderMme" class="form-label"> Mme. </label>

                        <input type="radio" class="form-check-input" value="2" name="gender" id="genderO">
                        <label for="genderO" class="form-label"> Autre</label>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="username" placeholder="Votre Pseudo" required="required" <?php if (isset($_SESSION['listOfErrors']['username']) && !empty($_SESSION['listOfErrors']['username'])) { echo ("value=" . $_SESSION['listOfErrors']['username'] . ""); } ?>>
                        </div>

                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="lastname" placeholder="Votre nom" required="required" <?php if (isset($_SESSION['listOfErrors']['lastname']) && !empty($_SESSION['listOfErrors']['lastname'])) { echo ("value=" . $_SESSION['listOfErrors']['lastname'] . ""); } ?>>
                        </div>

                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="firstname" placeholder="Votre prénom" required="required" <?php if (isset($_SESSION['listOfErrors']['firstname']) && !empty($_SESSION['listOfErrors']['firstname'])) { echo ("value=" . $_SESSION['listOfErrors']['firstname'] . ""); } ?>>
                        </div>

                        <div class="col-lg-6">
                            <input type="date" class="form-control" name="birthday" required="required" <?php if (isset($_SESSION['listOfErrors']['birthday']) && !empty($_SESSION['listOfErrors']['birthday'])) { echo ("value=" . $_SESSION['listOfErrors']['birthday'] . ""); } ?>>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <input type="email" class="form-control" name="email" placeholder="Votre email" required="required">
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-lg-6">
                            <input type="password" class="form-control" name="pwd" placeholder="Votre Mot De Passe" required="required">
                        </div>
                        <div class="col-lg-6">
                            <input type="password" class="form-control" name="pwdConfirm" placeholder="Confirmation du mot de passe" required="required">
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary " type='submit'> Envoyer</button>
            </form>
        </div>
    </section>
    <footer class="footer text-faded text-center py-5">
        <div class="container"><p class="m-0 small">Copyright &copy; Your Website 2023</p></div>
    </footer>
    <!-- Bootstrap core JS-->
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>
