<?php 
    include "core/functions.php"; 
    include "const.inc.php"; 

    session_start(); 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    $connect = connectDB(); 
    $queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "pack");
    $queryPrepared->execute();
    $packs = $queryPrepared->fetchAll(PDO::FETCH_ASSOC);

    $targetDir = "../assets/img/hotel/";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Liste des Packs</title>
    <link href="css/styles.css" rel="stylesheet"/>
    <link href="css/perso.css" rel="stylesheet" />
</head>
<body>
    <h1 class="site-heading text-center text-faded d-none d-lg-block">
        <span class="blue site-heading-upper mb-3">Choisissez votre pack parmi ceux là</span>
        <span class="site-heading-lower">Des packs construits pour votre plaisir</span>
    </h1>
    <section class="page-section cta">
        <div class="container row">
            <div class="col-xl-9 mx-auto">
                <?php
                // Parcourir et afficher les packs
                foreach ($packs as $pack) {
                    echo "<div class='row'>";
                    echo "<h2>{$pack['nom']}</h2>";
                    echo "<p>{$pack['description']}</p>";

                    // Bouton pour voir/fermer les hôtels du pack
                    echo "<button class='btn btn-primary' onclick=\"toggleHotels('hotels-{$pack['id']}')\">Voir les hôtels</button>";

                    echo "<div class='row' id='hotels-{$pack['id']}' style='display: none;'>";
                    // Extraire les IDs d'hôtels et récupérer les informations des hôtels
                    $hotelIds = explode('e', $pack['hotel_all']);

                    foreach ($hotelIds as $hotelId) {
                        $queryPrepared = $connect->prepare("SELECT * FROM " . DB_PREFIX . "hotel WHERE id = :hotel_id");
                        $queryPrepared->bindValue(':hotel_id', $hotelId, PDO::PARAM_INT);
                        $queryPrepared->execute();
                        $hotel = $queryPrepared->fetch(PDO::FETCH_ASSOC);

                        if ($hotel) {
                            echo "<br>"; 
                            echo "<div class='row'>";
                            echo "<br>"; 
                            echo "<h3>{$hotel['nom']}</h3>";
                            echo "<p mb-0>Emplacement: {$hotel['emplacement']}</p>";
                            echo "<p mb-0>Places: {$hotel['places']}</p>";
                            echo "<p mb-0>Prix: {$hotel['prix']}</p>";

                            // Affichage de l'image de l'hôtel
                            $hotelImageSrc = $targetDir . $hotel['id'] . '.png';
                            echo "<img class='intro-img img-fluid mb-3 mb-lg-0 rounded ms-lg-5 resized-image' src='{$hotelImageSrc}' alt='Image de l\'hôtel {$hotel['nom']}'>";
                            echo "<br>"; 
                            echo "</div>";
                        }
                    }

                    // Bouton pour recacher les hôtels
                    echo "<button class='btn btn-primary' onclick=\"toggleHotels('hotels-{$pack['id']}')\">Cacher les hôtels</button>";

                    // Bouton "Ajouter au panier"
                    echo "<form action='core/packresa.php' method='post'>";
                    echo "<input type='hidden' name='pack_id' value='{$pack['id']}' />";
                    echo "<button type='submit' class='btn btn-primary'>Ajouter au panier</button>";
                    echo "</form>";

                    echo "</div>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
    </section> 
    <script>
        function toggleHotels(divId) {
            var hotelsDiv = document.getElementById(divId);
            if (hotelsDiv.style.display === "none") {
                hotelsDiv.style.display = "block";
            } else {
                hotelsDiv.style.display = "none";
            }
        }
    </script>
</body>
</html>
